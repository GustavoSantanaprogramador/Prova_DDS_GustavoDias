/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gustavo_q4;

import javax.swing.JOptionPane;

/**
 *
 * @author gsantana
 */
public class Gustavo_Q4 {

    public static void main(String[] args) {
        System.out.println("Digite um número inteiro ");
        
        int inteiro = 0;
        
       
        JOptionPane.showInputDialog("Digite um número inteiro");
        JOptionPane.showInputDialog(inteiro + 1);
    }
}
